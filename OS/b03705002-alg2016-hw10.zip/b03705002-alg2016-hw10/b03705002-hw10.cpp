#include <iostream>
#include <cmath>
using namespace std;

class Graph //The Graph
{
public:
    int**matrix; //the edges
    bool**mark_e; //the marked edges
    int*vertex; //the vertices
    bool*mark_v; //the marked vertices
};

int main()
{
    int max=0; //the max of the edges, used to initialize max
    int request;
    int team;// catering teams
    while(cin>>request>>team)
    {
        bool flag=0; //a flag used to mention the end of one input
        Graph FindRoute; //The graph
        FindRoute.matrix= new int*[request+1]; //initialize edges
        FindRoute.mark_e= new bool*[request+1]; // and the mark
        for(int i=0;i<request+1;i++)
        {
            FindRoute.matrix[i]=new int[request+1];
            FindRoute.mark_e[i]=new bool[request+1];
        }
        //finish initializing marks and edges
        for(int i=0;i<request+1;i++)
        {
            //set them to 0
            for(int j=0;j<request+1;j++)
            {
                FindRoute.matrix[i][j]=0;
                FindRoute.mark_e[i][j]=0;
            }
        }
        for(int i=0;i<request;i++)
        {
            for(int j=i+1;j<request+1;j++)
            {
                cin>>FindRoute.matrix[i][j]; //input the edges
                if(FindRoute.matrix[i][j]>=max)
                {
                    max=FindRoute.matrix[i][j]; //and record the max
                }
            }
        }
        for(int i=0;i<request+1;i++)
        {
            for(int j=i;j<request+1;j++)
            {
                FindRoute.matrix[j][i]=FindRoute.matrix[i][j];
                //undirected graph has no direction,so a->b = b->a
            }
        }
        FindRoute.mark_v=new bool[request+1];
        FindRoute.vertex=new int[request+1]; //initialize vertex and marks
        for(int i=0;i<request+1;i++)
        {
            FindRoute.vertex[i]=i; //and vertex={0,1,...,request}
        }
        int min=max; //the min is used to find minium edge
        int min_e1=0; //and the v1
        int min_e2=0; //and the v2 e[v1,v2] is the edge
        int sum=0; //sum is the weight sum
        bool*key=new bool [request+1]; //keys, which are compatible to reach outsiders
        key[0]=1; //0 is the initial point, so it is the key
        for(int i=1;i<request+1;i++)
        {
            key[i]=0; //others,0
        }
        FindRoute.mark_v[0]=1; //0 is the initial point, it has been marked
        while(flag==0) //when an input isn't finished
        {
            for(int k=0;k<request+1;k++)
            {
                //check whether all vertices has been passed
                if(FindRoute.mark_v[k]==0)
                {
                    break; //no, then continue to MFS
                }
                if(FindRoute.mark_v[request]==1 && k==request)
                {
                    cout<<sum<<"\n"; //else,output sum
                    flag=1;//continue next input
                }
            }
            for(int i=0;i<request+1 && key[i]==1 ; i++) //if i is key
            {
                for(int j=0;j<request+1 && FindRoute.mark_e[i][j]==0;j++)//and e[i,j] isn't marked
                {
                    if(FindRoute.matrix[i][j]<=min && FindRoute.matrix[i][j]!=0 && FindRoute.mark_v[j]!=1)
                    {
                        //0 means no route, and j isn't marked
                        min=FindRoute.matrix[i][j]; //record min
                        min_e1=i; //and i,j
                        min_e2=j;
                    }
                }
            }
            if(min_e2!=0) //if there is a route
            {
                FindRoute.mark_e[min_e1][min_e2]=1; //mark the edge
                FindRoute.mark_v[min_e2]=1;// and the vertex added
                key[min_e2]=1; //and the vertex will be a key,too.
                sum+=min;//sum+=edge weight
            }
            //initialize
            min=max;
            min_e1=0;
            min_e2=0;
        }
    }
    return 0;
}